#!/bin/bash
m="\e[1;31m"
p="\e[1;0m"

echo -e "                      $p-----------------------------------"
echo -e "               Welcome To Premium Script Auto Install Vps By Mail"
echo -e "                        Telegram : https://t.me/zxbxns"
echo -e "                     Type$m [ Menu ]$p To Display Command List"
echo -e ""
